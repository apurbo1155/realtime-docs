const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// Serve static files
app.use(express.static('public'));

// Room management
let rooms = {};

io.on('connection', (socket) => {
  console.log('New user connected');

  socket.on('join_room', (room) => {
    socket.join(room);
    rooms[room] = rooms[room] || { users: new Set() };
    rooms[room].users.add(socket.id);
    
    socket.emit('room_joined', { room });
    io.to(room).emit('user_joined', { 
      userId: socket.id,
      userCount: rooms[room].users.size
    });
  });

  socket.on('document_update', (data) => {
    io.to(data.room).emit('sync_update', {
      content: data.content,
      userId: socket.id
    });
  });

  socket.on('disconnect', () => {
    Object.keys(rooms).forEach(room => {
      if (rooms[room].users.has(socket.id)) {
        rooms[room].users.delete(socket.id);
        io.to(room).emit('user_left', {
          userId: socket.id,
          userCount: rooms[room].users.size
        });
      }
    });
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});